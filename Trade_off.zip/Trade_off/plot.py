import torch , os
import numpy as np
from torch import nn, optim
import matplotlib.pyplot as plt
os.chdir('..')
from code_repository import Log_Reg, Read_data, test_LR, train_LR, PPS3, Log_Reg_PPS, PU_trade_off2
os.chdir('.\\Trade_off')
%matplotlib qt
from sklearn.model_selection import train_test_split
from sklearn.datasets import make_classification
# https://scikit-learn.org/stable/modules/generated/sklearn.datasets.make_classification.html
import pickle
from os.path import exists
import itertools

import os
os.environ["KMP_DUPLICATE_LIB_OK"]="TRUE"

torch.set_default_dtype(torch.float64)



STR_Vec = [('Bank',0, 10, 6), ('Satellite',1, 80, 25),
           ('Robot',2, 35, 10), ('Synthetic',3, 25, 8)]

fig, axs = plt.subplots(1,4)
for l in STR_Vec:
    mark = itertools.cycle((',', '+', '.', '*', 'x', 'd', 'v')) 
    lst = itertools.cycle(('-','--', '-.', ':')) 
    col = itertools.cycle(('b','g', 'r', 'c', 'm', 'y', 'k')) 
    
    
    Read = l[0]
    dpas = 0.2
    learning_rate = 0.05
    if Read=='Bank':
        os.chdir('./Bank')
        
        Model_name = 'LR_Model_Bank_NT.pckl'
        input_dim, output_dim, epochs, batch_size, Lambda = 19, 2, 600, 1000, 0.0
        if not exists(Model_name):
            X, Y= Read_data('bank-additional-full.csv')
            """Normalization"""
            X = (X - np.min(X, axis=0)) / (np.max(X, axis=0) - np.min(X, axis=0))
            """Train/test/validation set"""
            X_train, X_test, Y_train, Y_test = train_test_split(X,Y, test_size = 0.2, random_state=0)
            X_test, X_valid, Y_test, Y_valid = train_test_split(X_test,Y_test, test_size = 0.5, random_state=0)
            
            X_train, X_test, X_valid = torch.Tensor(X_train), torch.Tensor(X_test), torch.Tensor(X_valid)
            Y_train, Y_test, Y_valid = torch.LongTensor(Y_train), torch.LongTensor(Y_test), torch.LongTensor(Y_valid)
                    
            #Training the data
            model = Log_Reg(input_dim, output_dim) # Model with No Transformation
            CEF_loss = nn.CrossEntropyLoss()
            optimizer = optim.Adam(model.parameters(), lr=learning_rate)
            Final_model = train_LR(model, epochs, optimizer, CEF_loss, Lambda, batch_size, 
                                      X_train, Y_train, X_valid, Y_valid, 0)
            _ = test_LR(Final_model, X_test, Y_test, X_train, Y_train)
            
            Data = {'model': Final_model,
                    'Dataset': Read,
                    'Data': [X, Y, X_train.numpy(), Y_train.numpy(), X_test.numpy(), Y_test.numpy(), X_valid.numpy(), Y_valid.numpy()],
                    'dt': input_dim, 'Class': output_dim,
                    'lr': learning_rate, 'Lambda': Lambda,
                    'batch_size': batch_size, 'epochs': epochs}
            
            f = open(Model_name, 'wb')
            pickle.dump(Data, f)
            f.close()
        
        
    elif Read=='Satellite':
        os.chdir('./Satellite')
        
        Model_name = 'LR_Model_Satellite_NT.pckl'
        input_dim, output_dim, epochs, batch_size, Lambda = 36, 6, 600, 1000, 0.0
        if not exists(Model_name):
            X_tr, X_ts, Y_tr, Y_ts = Read_data('Sat_train.txt')
            X, Y = np.concatenate((X_tr, X_ts), axis = 0), np.concatenate((Y_tr, Y_ts), axis=0)
            """Normalization"""
            X = (X - np.min(X, axis=0)) / (np.max(X, axis=0) - np.min(X, axis=0))
            """Train/test/validation set"""
            X_train, X_test, Y_train, Y_test = train_test_split(X,Y, test_size = 0.2, random_state=0)
            X_test, X_valid, Y_test, Y_valid = train_test_split(X_test,Y_test, test_size = 0.5, random_state=0)
            
            X_train, X_test, X_valid = torch.Tensor(X_train), torch.Tensor(X_test), torch.Tensor(X_valid)
            Y_train, Y_test, Y_valid = torch.LongTensor(Y_train), torch.LongTensor(Y_test), torch.LongTensor(Y_valid)
        
            #Training the data
            model = Log_Reg(input_dim, output_dim) # Model with No Transformation
            CEF_loss = nn.CrossEntropyLoss()
            optimizer = optim.Adam(model.parameters(), lr=learning_rate)
            Final_model = train_LR(model, epochs, optimizer, CEF_loss, Lambda, batch_size, 
                                      X_train, Y_train, X_valid, Y_valid, 0)
            _ = test_LR(Final_model, X_test, Y_test, X_train, Y_train)
            
            Data = {'model': Final_model,
                    'Dataset': Read,
                    'Data': [X, Y, X_train.numpy(), Y_train.numpy(), X_test.numpy(), Y_test.numpy(), X_valid.numpy(), Y_valid.numpy()],
                    'dt': input_dim, 'Class': output_dim,
                    'lr': learning_rate, 'Lambda': Lambda,
                    'batch_size': batch_size, 'epochs': epochs}
            
            f = open(Model_name, 'wb')
            pickle.dump(Data, f)
            f.close()
        
    elif Read=='Robot':
        os.chdir('./Robot')
        
        Model_name = 'LR_Model_Robot_NT.pckl'
        input_dim, output_dim, epochs, batch_size, Lambda = 24, 4, 500, 1000, 0.0
        if not exists(Model_name):
            X, Y = Read_data('sensor_readings_24_data.txt')
            """Normalization"""
            X = (X - np.min(X, axis=0)) / (np.max(X, axis=0) - np.min(X, axis=0))
            """Train/test/validation set"""
            X_train, X_test, Y_train, Y_test = train_test_split(X,Y, test_size = 0.2, random_state=0)
            X_test, X_valid, Y_test, Y_valid = train_test_split(X_test,Y_test, test_size = 0.5, random_state=0)
            
            X_train, X_test, X_valid = torch.Tensor(X_train), torch.Tensor(X_test), torch.Tensor(X_valid)
            Y_train, Y_test, Y_valid = torch.LongTensor(Y_train), torch.LongTensor(Y_test), torch.LongTensor(Y_valid)
                    
            #Training the data
            model = Log_Reg(input_dim, output_dim) # Model with No Transformation
            CEF_loss = nn.CrossEntropyLoss()
            optimizer = optim.Adam(model.parameters(), lr=learning_rate)
            Final_model = train_LR(model, epochs, optimizer, CEF_loss, Lambda, batch_size, 
                                      X_train, Y_train, X_valid, Y_valid, 0)
            _ = test_LR(Final_model, X_test, Y_test, X_train, Y_train)
            
            Data = {'model': Final_model,
                    'Dataset': Read,
                    'Data': [X, Y, X_train.numpy(), Y_train.numpy(), X_test.numpy(), Y_test.numpy(), X_valid.numpy(), Y_valid.numpy()],
                    'dt': input_dim, 'Class': output_dim,
                    'lr': learning_rate, 'Lambda': Lambda,
                    'batch_size': batch_size, 'epochs': epochs}
            
            f = open(Model_name, 'wb')
            pickle.dump(Data, f)
            f.close()
        
    
    elif Read=='Synthetic':
        os.chdir('./Synthetic')
        
        """First we train the data without any transformation"""
        Model_name = 'LR_Model_Synthetic.pckl'    
        input_dim, output_dim, epochs, batch_size, Lambda = 10, 2, 500, 1000, 0.0
        if not exists(Model_name):
            X,Y = make_classification(n_samples=50000, n_features=input_dim, n_informative=9, n_redundant=0, n_repeated=0, 
                                      n_classes=output_dim, n_clusters_per_class=1, weights=None, 
                                      flip_y=0.1, class_sep=1.0, hypercube=True, 
                                      shift=1.0, scale=1.0, shuffle=True, random_state=0)
            
            X = (X - np.min(X, axis=0)) / (np.max(X, axis=0) - np.min(X, axis=0))
            
    
            #Train/test/validation set
            X_train, X_test, Y_train, Y_test = train_test_split(X,Y, test_size = 0.2, random_state=0)
            X_test, X_valid, Y_test, Y_valid = train_test_split(X_test,Y_test, test_size = 0.5, random_state=0)
            
            X_train, X_test, X_valid = torch.Tensor(X_train), torch.Tensor(X_test), torch.Tensor(X_valid)
            Y_train, Y_test, Y_valid = torch.LongTensor(Y_train), torch.LongTensor(Y_test), torch.LongTensor(Y_valid)
            
            #Training the data
            model = Log_Reg(input_dim, output_dim) # Model with No Transformation
            CEF_loss = nn.CrossEntropyLoss()
            optimizer = optim.Adam(model.parameters(), lr=learning_rate)
            Final_model = train_LR(model, epochs, optimizer, CEF_loss, Lambda, batch_size, 
                                      X_train, Y_train, X_valid, Y_valid, 0)
            _ = test_LR(Final_model, X_test, Y_test, X_train, Y_train)
            
            Data = {'model': Final_model,
                    'Dataset': Read,
                    'Data': [X, Y, X_train.numpy(), Y_train.numpy(), X_test.numpy(), Y_test.numpy(), X_valid.numpy(), Y_valid.numpy()],
                    'dt': input_dim, 'Class': output_dim,
                    'lr': learning_rate, 'Lambda': Lambda,
                    'batch_size': batch_size, 'epochs': epochs}
            
            f = open(Model_name, 'wb')
            pickle.dump(Data, f)
            f.close()
    
    
    LOSS = 'ESA'
    """Results for the model without Linear transformation"""
    f = open(Model_name, 'rb')
    Data = pickle.load(f)
    f.close()
    dact = Data['dt']-int(dpas*Data['dt'])
    print(int(dpas*Data['dt']))


    
    MSE1, MSE2, MSE3, KLD1, KLD2, KLD3, Class_label_MSE, Class_label_KLD = PU_trade_off2(Data, seed=0, Div=50, al_max=l[2], da=dact, CL_num = l[3])
    axs[l[1]].plot(KLD1, MSE1, linestyle=next(lst), marker = next(mark), color = next(col), linewidth=2 , label = 'Scheme1')
    axs[l[1]].plot(KLD2, MSE2, linestyle=next(lst), marker = next(mark), color = next(col), linewidth=2, label = 'Scheme2')
    axs[l[1]].plot(KLD3, MSE3, linestyle=next(lst), marker = next(mark), color = next(col), linewidth=2, label = 'Scheme3')
    axs[l[1]].plot(Class_label_KLD, Class_label_MSE, linestyle=next(lst), marker = next(mark), color = next(col), linewidth=2, label = 'Class label')
    axs[l[1]].set_xlabel('KLD ('+l[0]+')', fontsize=15)
    axs[l[1]].set_ylabel('MSE', fontsize=15)
    axs[l[1]].grid()
    if l[0]=='Bank':
        axs[l[1]].legend()
    
    os.chdir('..')
    
plt.show()


# MSE1, Acc1, TV1, CL_MSE1, CL_Acc1, CL_TV1 = PU_trade_off(Data, 0, itr=10, Div=200, da=dact, est='HS', noise='Normal', prob=0) # est = LS, HS, RCC1, RCC2, CLS
# MSE2, Acc2, TV2, _, _, _ = PU_trade_off(Data, 0, itr=10, Div=200, da=dact, est='HS', noise='BPSK', prob=0)
# # MSE3, Acc3, TV3, _, _, _ = PU_trade_off(Data, 0, itr=10, Div=50, da=dact, est='HS', noise='flash', prob=0.99)

# plt.plot(Acc1, MSE1, 'ob', label = 'Normal')
# plt.plot(Acc2, MSE2, '+r', label = 'BPSK')
# # plt.plot(Acc3, MSE3, '.g', label = 'Flash')
# plt.plot(CL_Acc1, CL_MSE1, 'xr')
# plt.title('MSE vs Acc')
# plt.legend()
# plt.show()

# plt.figure()
# plt.plot(TV1, MSE1, 'ob', label = 'Normal')
# plt.plot(TV2, MSE2, '+r', label = 'BPSK')
# # plt.plot(TV3, MSE3, '.g', label = 'Flash')
# plt.plot(CL_TV1, CL_MSE1, 'xk')
# plt.title('MSE vs TV')
# plt.legend()
# plt.show()